# FC25 Discord Bot

## Overview

This is a Discord bot for managing an FC25 (FIFA/EA Sports FC) gaming community. The bot provides player management and attribute training systems. Users can register as players, train their skills through various activities, and interact with the bot through Discord commands. The system tracks player statistics across multiple categories (Attack, Defense, Skill, Power, Movement, Mentality, and Goalkeeper attributes) and provides weekly training limits to ensure balanced progression.

## User Preferences

Preferred communication style: Simple, everyday language.
UI color scheme: Yellow embeds (0xFFFF00), red/green prev/next buttons, blue/red weekly/total buttons
No emojis in bot messages (removed per user request)

## System Architecture

### Backend Architecture

**Technology Stack:**
- **Runtime:** Node.js with TypeScript (ES2022/ESNext modules)
- **Bot Framework:** Discord.js v14 for Discord API integration
- **Database ORM:** Drizzle ORM with Neon serverless PostgreSQL adapter
- **Task Scheduling:** node-cron for scheduled operations
- **Development Tooling:** tsx for TypeScript execution with watch mode

**Design Pattern:**
Event-driven architecture using Discord.js client events. The bot listens for Discord gateway events (messages, interactions, etc.) and responds with database operations and Discord API calls. This pattern was chosen because it aligns with Discord's real-time nature and allows for scalable, non-blocking operations.

**Pros:**
- Real-time responsiveness to Discord events
- Scalable through Discord.js's built-in event handling
- TypeScript provides type safety for complex game attributes

**Cons:**
- Single point of failure (bot process must remain running)
- State management requires database queries for persistence

### Database Schema

**Primary Tables:**
1. **players** - Stores Discord user data and 30+ game attributes across 6 categories
   - Uses Turkish naming convention for attributes (e.g., "ortaAcma", "bitiricilik")
   - All attributes default to 50 and are stored as integers
   - Each player linked to Discord ID for authentication

2. **trainingLogs** - Tracks weekly training activities per player per attribute
   - Implements weekly training limits through timestamp-based tracking
   - Prevents attribute abuse by limiting progression speed

**Database Technology:** PostgreSQL via Neon serverless
- **Rationale:** Serverless PostgreSQL eliminates infrastructure management while providing full SQL capabilities needed for complex queries (training limits, leaderboards, etc.)
- **Alternative Considered:** SQLite was likely considered but rejected due to need for concurrent access in multi-user Discord environment

### Attribute System

**Architecture Decision:** Multi-category attribute system with weekly training limits

The bot implements 6 categories of player attributes:
- Atak (Attack) - 5 attributes
- Savunma (Defense) - 2 attributes  
- Beceri (Skill) - 5 attributes
- Güç (Power) - 5 attributes
- Hareket (Movement) - 5 attributes
- Mentalite (Mentality) - 5 attributes
- Kaleci (Goalkeeper) - partial implementation visible

**Design Decision:** Weekly training fields separate from base attributes
- Each attribute has both a permanent field (e.g., "ortaAcma") and weekly training field (e.g., "weeklyOrtaAcma")
- This dual-field system allows tracking of short-term vs. long-term progression

**Alias System:** Multiple text variations accepted for each attribute to improve user experience
- Example: "kısa pas", "kisa pas", "kisapas" all map to same attribute
- Handles Turkish character variations (ı/i, ş/s, etc.)

### Command Architecture

**Available Commands:**
- `.komutlar` - List all available commands
- `.nitelikler` - Show all trainable attributes by category
- `.s` / `.s @user` - Display player attributes (paginated, trained only)
- `+1 nitelik` - Train an attribute (1-hour cooldown)
- `.sırala` - Show weekly leaderboard (top 10 by weekly progress)
- `.ekle @user nitelik +value` - Admin: add attribute with mandatory reason via modal
- `.sıfırla` - Admin: reset all players to base attributes (50)
- `.fulle @user` - Special: set all attributes to 99 (alonedark13. only)

**Interaction Model:** Message-based command system with:
- Message content parsing (GatewayIntentBits.MessageContent enabled)
- Interactive components (ButtonBuilder for pagination and view switching)
- Modal dialogs for admin action reasons

**Rationale:** Message-based commands are intuitive for players, while interactive components reduce typing errors. Modals ensure admin actions are documented with reasons.

### Scheduled Tasks

**Technology:** node-cron for periodic operations
- Weekly reset of training progress (every Monday at midnight UTC)
- Resets all weekly training fields to 0, preserving base attribute values

**Design Decision:** In-process scheduling rather than external cron
- **Pro:** Simpler deployment (no separate scheduler needed)
- **Con:** Resets only occur when bot is running

### Permission System

**Discord Permissions:** Uses PermissionFlagsBits and GuildMember checks
- Implements role-based access control through Discord's native permission system
- No custom permission layer needed - leverages Discord's existing infrastructure

## External Dependencies

### Core Services

**Discord API:**
- **Service:** Discord.js v14 library
- **Purpose:** All bot interactions, message sending, slash commands, interactive components
- **Authentication:** Bot token (configured via Discord Developer Portal)

**Database:**
- **Service:** Neon Serverless PostgreSQL (@neondatabase/serverless)
- **Purpose:** Persistent storage for players, training logs, tickets
- **Configuration:** DATABASE_URL environment variable required
- **Connection:** WebSocket-based connection pool using 'ws' library

### Development Dependencies

**TypeScript Toolchain:**
- TypeScript 5.9+ for type safety
- tsx for development with hot reload (watch mode)
- Path aliases configured (@shared/* pattern)

**Database Management:**
- drizzle-kit for schema migrations and database push operations
- Schema definition in shared/schema.ts for type safety across application

### Environment Variables

**Required:**
- `DATABASE_URL` - PostgreSQL connection string (validated at startup in both drizzle.config.ts and server/db.ts)
- Discord bot token (implicitly required by Discord.js client)

**Error Handling:** Application throws errors on startup if DATABASE_URL is missing, preventing silent failures

## Recent Changes (November 30, 2025 - Latest Update)

### UI Customizations
- **Color Scheme:** Changed embed color from green (0x00ff00) to yellow (0xFFFF00)
- **Button Styling:**
  - Previous button: Red (Danger style)
  - Next button: Green (Success style)  
  - Weekly button: Blue (Primary style)
  - Total button: Red (Danger style)
- **Message Content:** Removed all emojis from bot messages per user request

### Ticket System Changes
- **Removed:** "Nitelik Ekle" (Add Attribute) button from ticket interface
- **Impact:** Attributes can no longer be added via ticket system
- **Reason field:** Moved to `.ekle` admin command (now mandatory)

### Admin Command (.ekle) Enhancement
- **Old behavior:** `.ekle @user attribute +value` - Directly added attribute
- **New behavior:** 
  1. Admin types `.ekle @user attribute +value`
  2. Bot responds with confirmation button "Sebep ile Onayla" (Confirm with Reason)
  3. Admin clicks button → Modal opens asking for reason (5-500 chars, mandatory)
  4. Admin submits reason → Attribute added with reason logged
- **Benefit:** All attribute additions now require documented reason for audit trail
- **Data storage:** Reason stored in `pendingAddAttributeData` Map during flow, shown in confirmation

### Ticket System Removal
- **Removed:** Entire ticket system including:
  - `ticketkur` slash command
  - Ticket creation and management functionality
  - Ticket-related database operations
  - All ticket interaction handlers (specialist selection, ticket closing)
- **Database:** `tickets` table remains in schema but is no longer used (can be removed in future)
- **Reason:** User preference for simplified command-based interface

### .komutlar Command Addition
- **Feature:** New command listing all available bot commands
- **Display:** Yellow embed (0xFFFF00) with formatted command descriptions
- **Contents:** Shows 8 main commands with usage examples and permission levels
- **Use case:** Allows new players to discover all available interactions without separate documentation

### Code Structure
- **State Management Maps:**
  - `trainingCooldown`: Tracks 1-hour training cooldown per user
  - `pendingAddAttributeData`: Temporary storage for attribute additions awaiting reason confirmation
- **Removed:** 
  - `ticketCounters`, `ticketCategories`, `ticketClosingQueue` Maps
  - `registerSlashCommands()`, `handleTicketSetup()`, `setupTicketAsync()`, `initializeTicketCounters()` functions
  - All ticket-related interaction handlers